#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <QWebFrame>
#include "mainwindow.h"



MainWin::MainWin(QWidget *parent)
: QWebView(parent)
{
	QUrl startURL = QUrl("https://www.google.de");
	setUrl(startURL);
}
