#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <QApplication>
#include <QWebView>
#include "mainwindow.h"



int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	MainWin mainWindow;
	mainWindow.setGeometry(0, 0, 1280, 720);
	mainWindow.showMaximized();
	return app.exec();
}
