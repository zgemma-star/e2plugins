#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWebView>



class MainWin : public QWebView
{
    Q_OBJECT

public:
    explicit MainWin(QWidget * parent = 0);
};
#endif
